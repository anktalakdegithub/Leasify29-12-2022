<?= $this->extend('nbfc/headers')?>
<?= $this->section('content')?>
<div class="my-auto text-center">
<h2 class="text-center">Sorry, Your varfication is pending due to that You are not able to generate BID</h2>

</div>
<?=  $this->endSection()?>