<?= $this->extend('nbfc/headers')?>
<?= $this->section('content')?>
<div class="my-auto text-center">
<h2 class="text-center">Thank You So Much</h2>
<p class=" text-center">You Placed Your BID Successfully</p>
</div>
<?=  $this->endSection()?>