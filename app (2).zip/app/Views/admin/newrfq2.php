<?= $this->extend('admin/header_candidate')?>
<?= $this->section('content')?>

<!-- Content wrapper -->
<div class="content-wrapper">
    <!-- Content -->

    <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="fw-bold py-3 mb-4">RFQ List</h4>


        <div class="row">
            <div class="col-md-12">
                <h5>Latest RFQ's </h5>
                <div class="card">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-2 text-center">
                                <img class="card-img-top" src="<?=base_url();?>/public/assets/img/elements/19.jpg" alt="" style="width:50%;">
                            </div>
                            <div class="col-md-10">
                                <h6>Lorem ipsum dolor sit amet.</h6>
                                <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Voluptates corrupti dolorem
                                    earum maiores, explicabo quidem unde magni iste rerum.</p>
                            </div>
                        </div>

                    </div>
                </div>
                <hr>
                <div class="card">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-2 text-center">
                                <img class="card-img-top" src="<?=base_url();?>/public/assets/img/elements/19.jpg" alt="" style="width:50%;">
                            </div>
                            <div class="col-md-10">
                                <h6>Lorem ipsum dolor sit amet.</h6>
                                <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Voluptates corrupti dolorem
                                    earum maiores, explicabo quidem unde magni iste rerum.</p>
                            </div>
                        </div>

                    </div>
                </div>
                <hr>
                <div class="card">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-2 text-center">
                                <img class="card-img-top" src="<?=base_url();?>/public/assets/img/elements/19.jpg" alt="" style="width:50%;">
                            </div>
                            <div class="col-md-10">
                                <h6>Lorem ipsum dolor sit amet.</h6>
                                <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Voluptates corrupti dolorem
                                    earum maiores, explicabo quidem unde magni iste rerum.</p>
                            </div>
                        </div>

                    </div>
                </div>

            </div>
        </div>
    </div>
    <!-- / Content -->
    
    <?=  $this->endSection()?>