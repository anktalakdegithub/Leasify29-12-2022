<?= $this->extend('admin/header_candidate')?>
<?= $this->section('content')?>

<!-- Content wrapper -->
<div class="content-wrapper">
    <!-- Content -->

    <div class="container-xxl flex-grow-1 container-p-y">



        <div class="row">
            <div class="col-6">
                <h4 class="fw-bold py-3 mb-4">NBFC's</h4>
            </div>
            <div class="col-6">
                <div class="row">
                    <div class="col-5">
                       
                    </div>
                    <div class="col-md-5 px-1">
                        <div class="row">
                            <div class="input-group input-group-merge">

                                <input type="text" class="form-control" id="search" placeholder="Search..." aria-label="Search..."
                                    aria-describedby="basic-addon-search31" />
                                <!-- <span class="input-group-text" id="basic-addon-search31"><i
                                        class="bx bx-search"></i></span> -->
                            </div>
                        </div>
                    </div>
                    <div class="col-md-2 text-start">
                            <button class="search_order_data btn btn-primary"  type="button" name="button"><i
                                             class="bx bx-search"></i></button>
                    </div>

                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-12">
                <div class="table-responsive text-nowrap bg-white" id="exportdata">
                    <table class="table table-hover">
                        <thead class="table-dark">
                            <tr>
                                <td>ID</td>
                                <td>Name</td>
                                <td>Phone Number</td>
                                <td>Email</td>
                                <td>Action</td>
                            </tr>
                        </thead>
                        <tbody class="table-border-bottom-0">
                            <?php  $i=1;
                            if(is_array($nbfc) && count($nbfc) > 0){
                            // print_r($nbfc);die();
                            foreach($nbfc as $nb){
                            ?>
                            <tr>
                                <td><?= $i++;?></td>
                                <td><?php echo $nb['firstname'];?> <?=$nb['lastname'];?></td>
                                <td><?=$nb['mobile_number']; ?></td>
                                <td><?=$nb['emailid']; ?></td>

                                <td>
                                    <div class="dropdown">
                                        <button type="button" class="btn p-0 dropdown-toggle hide-arrow"
                                            data-bs-toggle="dropdown">
                                            <i class="bx bx-dots-vertical-rounded"></i>
                                        </button>
                                        <div class="dropdown-menu">
                                            <a class="dropdown-item" href="edit_cust?id=<?=$nb['user_id']?>"><i
                                                    class="bx bx-edit-alt me-1"></i>
                                                Edit</a>
                                            <a class="dropdown-item" href="javascript:void(0);" data-bs-toggle="modal"
                                                data-bs-target="#basicModal_<?=$nb['user_id']?>"><i
                                                    class="bx bx-trash me-1"></i> Delete</a>
                                        </div>
                                    </div>
                                </td>

                            </tr>
                            <?php
                            }}else{ ?>
                                <tr class="text-center">
                                  <td colspan="6">
                                <p class="text-center">No Data Found</p>
                                </td>
                                </tr>
                               <?php } ?>

                        </tbody>
                      
                    </table>
                </div>
                <div class=" bg-white" id="invoice"></div>
                <div class="mt-3" >
                <?php echo $pager->links();?>
                </div>
               
            </div>
        </div>
        <?php
                        foreach($nbfc as $nb){
                        ?>
        <!-- Modal -->
        <div class="modal fade" id="basicModal_<?=$nb['user_id']?>" tabindex="-1" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel1">Are You Sure ?</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>

                    <div class="modal-footer">
                        <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">
                            No
                        </button>
                        <button type="button" class="btn btn-primary delete_nbfc"
                            value="<?=$nb['user_id'];?>">Yes</button>
                    </div>
                </div>
            </div>
        </div>
        <?php
                        }
                        ?>


    </div>
    <!-- / Content -->


    <?=  $this->endSection()?>
    <?= $this->section('scripts')?>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script>
    $('body').on('click', '.delete_nbfc', function() {


        var id = $(this).val();
        $.ajax({

            url: "<?php echo base_url('delete_cust');?>",

            data: {
                id: id,
            },

            type: "post",

            success: function(response) {
                // alert(response);
                window.location.href = "<?php echo base_url('admin/nbfc');?>";

            }

        });
    });
    </script>
     <script>
             $(document).ready(function() {
        $('.search_order_data').on('click', function(e) {

            $.ajax({

                url: '<?=base_url();?>/admin/searchnbfc',
                data: {
                    // 'fromdate': $('#fromDate').val(),
                    // 'todate': $('#toDate').val(),
                    'search': $('#search').val()

                },
                type: 'post',
                success: function(response) {
                  
                     document.getElementById("exportdata").style.display = "none";
                    //    alert();
                    $('#invoice').html(response);
                      // alert();
                 
                }
            })
        });
    });
    </script>
    <?=  $this->endSection()?>