<?= $this->extend('header')?>
<?= $this->section('content')?>
<!-- ====== Banner Start ====== -->
<section class="ud-abtfooter wow fadeInUp" data-wow-delay=".15s">
    <div class="shape shape-1">
        <img src="<?=base_url();?>/public/assetsl/images/Contactus_Illustrationnew.png" class="imgabt imgcon" alt="shape" />
    </div>


    <div class="ud-footer-widgets">
        <div class="container">
            <div class="row">
                <h1 class="textcolor text-end footheading conhead">Contact Us</h1>
            </div>
        </div>
    </div>
</section>
<!-- ====== Banner End ====== -->

<!-- ====== Contact Start ====== -->
<section id="contact" class="ud-contact">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-xl-8 col-lg-7">
                <div class="ud-contact-content-wrapper">
                    <div class="ud-contact-title">

                        <span class="text-white">CONTACT US</span>
                        <h2 class="smarttitle">
                            We'd Love to hear you!
                        </h2>
                    </div>
                    <div class="ud-contact-info-wrapper">

                        <div class="row">
                            <div class="col-md-6 col-sm-12">
                                <div class="row">
                                    <div class="col-2 "> <img src="<?=base_url();?>/public/assetsl/images/clogo/Address_Icon.png" width="60px"
                                            alt=""></div>
                                    <div class="col-10 pt-2">
                                        <h5 class="mb-2 conpara">Our Location</h5>

                                        <p>310-311, Crescent Business Park,
                                            Andheri East, Mumbai-72</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 col-sm-12">
                                <div class="row">
                                    <div class="col-2 "> <img src="<?=base_url();?>/public/assetsl/images/clogo/Email_ICon.png" width="60px"
                                            alt=""></div>
                                    <div class="col-10 pt-2">
                                        <h5 class="mb-2 conpara">We're Just An Email Away</h5>
                                       <a href="mailto:business@leasify.in">
                                        <p>business@leasify.in</p></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-4 col-lg-5">
                <div class="ud-contact-form-wrapper wow fadeInUp" data-wow-delay=".2s">
                    <h3 class="ud-contact-form-title">Send us a Message</h3>
                    <form class="ud-contact-form">
                        <div class="ud-form-group">
                            <label for="fullName">Full Name*</label>
                            <input type="text" name="fullName" id="name" placeholder="Adam Gelius" />
                        </div>
                        <div class="ud-form-group">
                            <label for="email">Email*</label>
                            <input type="email" name="email" id="email" placeholder="example@yourmail.com" />
                        </div>
                        <div class="ud-form-group">
                            <label for="types">Select Option</label>
                            <select class="form-select" id="selectoption" aria-label="Default select example">
                                <option value="NBFC">NBFC</option>
                                <option value="Investors">Investors</option>
                                <option value="Corporates">Corporates</option>
                                <option value="Invest Bank">Investment Bank</option>
                                <option value="DSA">DSA</option>
                                <option value="Other">Other</option>
                            </select>

                        </div>
                        <div class="ud-form-group">
                            <label for="phone">Phone*</label>
                            <input type="text" id="phone" name="phone" placeholder="+885 1254 5211 552" />
                        </div>
                        <div class="ud-form-group">
                            <label for="message">Message*</label>
                            <textarea name="message" id="message" rows="1"
                                placeholder="type your message here"></textarea>
                        </div>
                        <div class="ud-form-group mb-0">
                            <button type="button" class="ud-main-btn" id="sendmsg">
                                Send Message
                            </button>
                        </div>
                        <div id="msgs"></div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- ====== Footer Start ====== -->
<?=  $this->endSection()?>
<?= $this->section('scripts')?>
<script>
    $('#sendmsg').on('click', function () {

    //   alert();
      var name = $('#name').val();
      var email = $('#email').val();
      var selectoption = $('#selectoption').val();
      var phone = $('#phone').val();
      var message = $('#message').val();

      $.ajax({
        url: "<?=base_url();?>/savecondata",
        data: { 'name': name, 'email': email, 'selectoption': selectoption, 'phone': phone, 'message': message },
        dataType: "json",
        type: "post",
        success: function (data) {

          //  debugger;
          if (data.code == "404") {
            $('#msgs').html('<div class="alert alert-danger mt-3" role="alert">' + data.msg + '</div>');
          }
          else {
            $('#msgs').html('<div class="alert alert-success mt-3" role="alert">' + data.msg + '</div>');
            // purchase_product();
            window.location.href = "<?=base_url();?>/thankyou";			

          }

        }
      });
    });

</script>
<?=  $this->endSection()?>