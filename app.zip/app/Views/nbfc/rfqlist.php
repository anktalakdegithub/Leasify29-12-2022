<?= $this->extend('nbfc/headers')?>
<?= $this->section('content')?>

<!-- Content wrapper -->
<div class="content-wrapper">
    <!-- Content -->

    <!-- <div class="container-xxl flex-grow-1 container-p-y"> -->
    <div class="container-xxl flex-grow-1 container-p-y">
        <h2 class="fw-bold py-4 mt-2 text-center indicative">Indicative Proposals</h2>
        <!-- <h4 class="fw-bold py-2 mb-2">RFQ List</h4> -->
        <div class="row">
            <div class="col-md-6"></div>
            <div class="col-md-6 text-end">
                <!-- <a href="new_rfq.php" class="btn btn-primary my-3 text-white"> Create RFQ</a> -->
            </div>
        </div>


        <div class="row">
            <!-- Grid Card -->
            <!-- <h6 class="pb-1 mb-4 text-muted">Grid Card</h6> -->

            <div class="row" id="load_data">

            </div>
            <input type="hidden" id="page" value="1" />
            <div id='load_data_message' class="my-3"></div>


        </div>
    </div>
    <!-- / Content -->

    <?=  $this->endSection()?>
    <?= $this->section('scripts')?>
    <script>
    $(document).ready(function() {

        var limit = 6;
        var start = 0;
        var startimg = 0;
        var limitimg = 1;
        var action = 'inactive';
        var id = $('#id').val();

        function lazzy_loader(limit) {
            var output = '';
            for (var count = 0; count < limit; count++) {
                output += '<div class="post_data">';
                output +=
                    '<p><span class="content-placeholder" style="width:100%; height: 30px;">&nbsp;</span></p>';
                output +=
                    '<p><span class="content-placeholder" style="width:100%; height: 100px;">&nbsp;</span></p>';
                output += '</div>';
            }
            $('#load_data_message').html(output);
        }

        lazzy_loader(limit);

        function load_data(limit, start, limitimg, startimg) {
            // alert();
            // debugger
            var page = parseInt($('#page').val()) + 1;
            $.ajax({
                url: '<?=base_url();?>/nbfc/fetch_category',
                method: "POST",
                data: {
                    limit: limit,
                    start: start,
                    page: $('#page').val(),
                    id: id,
                    limitimg: limitimg,
                    startimg: startimg,

                },
                cache: false,
                success: function(data) {
                    // debugger

                    if (data == '') {
                        $('#load_data_message').html('');
                        action = 'active';
                    } else {
                        $('#page').val(page + 1);
                        $('#load_data').append(data);
                        $('#load_data_message').html("");
                        action = 'inactive';
                    }
                }
            })
        }


        if (action == 'inactive') {
            action = 'active';
            load_data(limit, start, limitimg, startimg);
        }

        $(window).scroll(function() {
            if ($(window).scrollTop() + $(window).height() > $("#load_data").height() && action ==
                'inactive') {
                lazzy_loader(limit);
                action = 'active';
                start = start + limit;
                setTimeout(function() {
                    load_data(limit, start, limitimg, startimg);
                }, 1000);
            }
        });

    });
    </script>

    <?=  $this->endSection()?>