<?= $this->extend('nbfc/headers')?>
<?= $this->section('content')?>
<style>
    .cardimg{
        height: 250px;overflow: hidden;
    }
    .inputlight{
        position: relative;
    top: 85%;
    transform: translateY(50%);
    }
    @media only screen and (min-width: 1260px) and (max-width: 1330px) {
        .inputlight{
             position: relative;
            top: 80%;
            transform: translateY(50%);
        }
    }
    @media only screen and (min-width: 1219px) and (max-width: 1265px) {
        .inputlight{
             position: relative;
            top: 65%;
            transform: translateY(50%);
        }
    }
    @media only screen and (min-width: 1205px) and (max-width: 1214px) {
        .inputlight{
             position: relative;
            top: 37%;
            transform: translateY(50%);
        }
    }
    html:not(.layout-footer-fixed) .content-wrapper {
    padding-bottom: 0 !important;
    background-color: white!important;
}
</style>
<div class="content-wrapper">
    <!-- Content -->

    <div class="container-xxl flex-grow-1 container-p-y">
        <div class="row">
            <div class="col-lg-8 col-md-12 col-sm-12">
                <h3>
                    <i class='bx bx-left-arrow-alt'></i><span>
                        <img src="https://s3.ap-south-1.amazonaws.com/docs.gripinvest.in/production/asset/472/website/logo/btry.gif"
                            height="44px" alt="">
                    </span>
                </h3>
                <h4 class="mt-3">Exclusive Combo of Tiger Global Portfolio Companies</h4>
                <div class="demo-inline-spacing">
                    <span class="badge bg-label-secondary">Secondary</span>
                    <span class="badge bg-label-secondary">Secondary</span>

                    <span class="badge bg-label-dark">Dark</span>
                    <span class="badge bg-label-secondary">Secondary</span>
                    <span class="badge bg-label-secondary">Secondary</span>

                    <span class="badge bg-label-dark">Dark</span>
                </div>
                <p class="cardimg" style="">
                    <img src="<?=base_url();?>/public/assetsl/images/business.jpg" class="mt-3 img-fluid"
                        style="border-radius:25px;" alt="">
                </p>
                <div class="card" style="margin: -35px 10px 0px;border: 4px solid #184b8140;">
                    <div class="card-body">

                        <div class="row">
                            <div class="col-md-4 col-sm-12 text-center">
                                <h4>16%</h4>
                                <p>Pre Tax Return (IRR)</p>
                            </div>
                            <div class="col-md-4 col-sm-12 text-center">
                                <h4>30 months</h4>
                                <p>Tenure</p>
                            </div>
                            <div class="col-md-4 col-sm-12 text-center">

                                <div class="progress" style="height: 5px">
                                    <div class="progress-bar" role="progressbar" style="width: 25%" aria-valuenow="25"
                                        aria-valuemin="0" aria-valuemax="100"></div>
                                </div>
                                <p class="mt-2"><b>24%</b> Completed</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-12 col-sm-12 px-2 text-center"
                style="background: url(http://localhost/leasiffronts/public/assets/img/deal/Iwanttoinvest.png);background-size: contain;background-repeat: no-repeat;height: auto;">
                <div class="container">
                    <div class="row ">
                        <div class="col-md-8">
                            <div class="row inputlight" >
                                <div class="col-12">
                                    <form action="">
                                        <input type="text" class="form-control border-0" style="width: 84%;background-color: #aad4f7;">
                                    </form>
                                </div>
                                <div class="col-12 mt-3 pe-5">
                                    <p class="px-0 mb-0">Pre Tax Return (IRR): 16%</p>
                                    <p class="px-0 pt-1">Pre Tax Return (IRR): 16%</p>
                                    <a href="#">
                                        <img src="<?=base_url();?>/public/assets/img/deal/nextbutton.png" height="30px" alt="">
                                    </a>
                                </div>
                              
                              
                            </div>
                        </div>
                        <div class="col-md-4"></div>

                    </div>
                </div>
            </div>
        </div>
    </div>

    <?=  $this->endSection()?>