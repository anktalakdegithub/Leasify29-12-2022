<?= $this->extend('nbfc/headers')?>
<?= $this->section('content')?>
<!-- Content wrapper -->
<div class="content-wrapper">
    <!-- Content -->

    <div class="container-xxl flex-grow-1 container-p-y">
        <h2 class="fw-bold py-3 mb-4 text-center text-dark">Active Proposal</h2>




        <div class="row">
            <div class="col-md-12">
                <div class="table-responsive text-nowrap bg-white mb-4">
                    <table class="table table-hover">
                        <thead class="table-dark">
                            <tr>
                                <td>ID</td>
                                <td>Bid</td>
                                <td>Title</td>
                                <td>Quote Value</td>
                                <td>Delivered By</td>
                                <td>Status</td>
                            </tr>
                        </thead>
                        <tbody class="table-border-bottom-0">
                        
                        <?php if(is_array($all_nbfc_active) && count($all_nbfc_active) > 0){ $i=1; foreach($all_nbfc_active as $nbfc){ ?>
                            <tr>

                                <td><?= $i++; ?></td>
                                <td><?= $nbfc['proposal_bid']; ?></td>
                                <td><?= $nbfc['proposal_title']; ?></td>
                                <td><?= $nbfc['min_investment'];?></td>
                                <td><?= $nbfc['proposal_date'];?></td>
                                <td>
                                <?php if($nbfc['investor_publish']==1){?>
                                  <span class="badge bg-label-success me-1">Accepted</span>
                                  <?php }elseif($nbfc['investor_publish']==0){ ?>
                                    <span class="badge bg-label-danger me-1">Pending</span>
                                    <?php } ?>
                                </td>
                            </tr>
                            <?php }}else{ ?>
                        <tr class="text-center">
                          <td colspan="6">
                        <p class="text-center">No Data Found</p>
                        </td>
                        </tr>
                       <?php } ?>
                           

                        </tbody>
                    </table>
                </div>
                <?php echo $pager->links();?>
            </div>
        </div>


    </div>
    <!-- / Content -->

    <?=  $this->endSection()?>