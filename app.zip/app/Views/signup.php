<?= $this->extend('header')?>
<?= $this->section('content')?>
<!-- ====== Header End ====== -->

<!-- ====== Banner Start ====== -->

<section class="ud-abtfooter wow fadeInUp" data-wow-delay=".15s">
    <div class="shape shape-3">
        <img src="<?=base_url();?>/public/assetsl/images/SignUpillustration.png" class="imgcon" alt="shape" />
    </div>
    <div class="ud-footer-widgets">
        <div class="container">
            <div class="row">
                <h1 class="textcolor text-start footheading">Sign Up</h1>
            </div>
        </div>
    </div>
</section>
<!-- ====== Banner End ====== -->

<!-- ====== Login Start ====== -->
<section class="ud-login">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="ud-login-wrapper">
                    <div class="ud-login-logo">
                        <!-- <img src="assets/images/logo/logo-2.svg" alt="logo" /> -->
                        <h3 class="text-center">Leasify</h3>
                    </div>
                    <form class="ud-login-form">
                        <div class="row">
                            <div class="col-md-6">
                            <div class="ud-form-group">
                            <input type="text" name="first_name" placeholder="First Name" id="first_name" />
                            </div>
                            </div>
                            <div class="col-md-6">
                            <div class="ud-form-group">
                            <input type="text" name="last_name" placeholder="Last Name" id="last_name" />
                        </div>
                            </div>
                        </div>
                       
                       
                        <div class="ud-form-group">
                            <!-- <label for="types" class="text-start">Select Option</label> -->
                            <!-- <input type="email" name="email" placeholder="example@yourmail.com" /> -->
                            <select class="form-select" id="user_type" aria-label="Default select example">
                                <option selected>Select Option</option>
                                <option value="investor">Investors</option>
                                <option value="nbfc">NBFC</option>
                                <option value="customer">Customer</option>
                            </select>
                        </div>
                        <div class="ud-form-group">
                            <input type="email" name="email" placeholder="Email" id="email" />
                        </div>
                        <div class="ud-form-group">
                            <input type="tel" name="mobile" placeholder="Contact Number" id="phone" />
                        </div>
                        <div class="ud-form-group">
                            <input type="password" name="password" placeholder="Password" id="password" />
                        </div>
                   
                        <div class="ud-form-group">
                            <button type="button" class="ud-main-btn w-100" id="signup">Sign Up</button>
                        </div>
                        <br>
                        <p id="msg"></p>
                    </form>



                    <p class="signup-option">
                    Already have an account? <a href="<?=base_url();?>/login"> Login </a>
                    </p>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- ====== Login End ====== -->

<!-- ====== Footer Start ====== -->
<?=  $this->endSection()?>
<?= $this->section('scripts')?>
<script>
   $('#password').hide(); 
    $('#user_type').change(function(){
        if($('#user_type').val() == 'customer') {
            $('#password').hide(); 
        } 
        if($('#user_type').val() == 'investor') {
            $('#password').show(); 
        } 
        if($('#user_type').val() == 'nbfc') {
            $('#password').show(); 
        } 
    });
</script>
<script>
$('#signup').click(function() {
    var fname = $('#first_name').val();
    var lname = $('#last_name').val();
    var email = $('#email').val();
    var phone = $('#phone').val();
    var password = $('#password').val();
    var user_type = $('#user_type').val();
    $.ajax({
        url: "<?=base_url();?>/process_signup",
        data: {
            fname: fname,
            lname: lname,
            email: email,
            phone: phone,
            user_type: user_type,
            password: password
        },
        type: "post",
        dataType: 'json',
        success: function(data) {
            if (data.code == 200) {
                $('#msg').html('<p class="text-success">' + data.msg + '</p>');
                window.location.href = "<?=base_url();?>/thankyou";
                // alert();

            } else {
                $('#msg').html('<p class="text-danger">' + data.msg + '</p>');
            }
        }
    });
});
</script>
<?=  $this->endSection()?>
