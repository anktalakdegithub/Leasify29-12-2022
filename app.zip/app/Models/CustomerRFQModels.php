<?php namespace App\Models;
use CodeIgniter\Model;
class CustomerRFQModels extends Model{
     
    protected $table= 'rfq';
    protected $allowedFields = ['rfqtitlte','subject','expiry_date','additional_details','total_cost'];


    public function saverfq($cust_id,$rfqtitle,$rfqsub,$expirydate,$additionaldetails,$totalcost)
    {	date_default_timezone_set('Asia/Kolkata');
        $resource="Website";
		$date=date("Y-m-d h:i:sa");
        $data=array('customer_id' => $cust_id,
        'rfqtitlte' =>$rfqtitle,
        'subject'=> $rfqsub,
        'expiry_date'=>$expirydate,
        'additional_details'=>$additionaldetails,
        'total_cost'=>$totalcost,
        'resource'=>$resource,
        'created_at'=>$date,
        'updated_at'=>$date);
         // $this->db->query("insert into rfq (rfqtitlte, subject,expiry_date,additional_details,total_cost,resource,created_at,updated_at) values ('$rfqtitle', '$rfqsub','$expirydate','$additionaldetails','$totalcost','$resource','$date','$date')");
        $this->db->table('rfq')->insert($data);
        $rfq_id=$this->db->insertID();
        return $rfq_id;
    }
    public function saverfqreq($cust_id,$rfq_id,$description,$cost,$quantity)
    {	date_default_timezone_set('Asia/Kolkata');
		$date=date("Y-m-d h:i:sa");
        $query="insert into rfq_requirement (customer_id, rfq_id, requiremnet_details, cost, quantity,created_at,updated_at) values ";
        
        $i=0;
        foreach ($description as $desc) {
            $query.="('$cust_id','$rfq_id','$desc', '$cost[$i]','$quantity[$i]','$date','$date'),";
            $i++;
        }
        $query=rtrim($query, ",");
        // print_r($query);
        $this->db->query($query);
    }

    public function updatecustomerdetails($mem_id,$is_check){
        date_default_timezone_set('Asia/Kolkata');
		$date=date("Y-m-d h:i:sa");
        $query= $this->db->query("update rfq set is_approved='$is_check',created_at='$date',updated_at='$date' where rfq_id='$mem_id'");
        // print_r($query);die();
      
    }
    
}
?>