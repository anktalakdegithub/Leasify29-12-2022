<?php namespace App\Models;
use CodeIgniter\Model;
class KycDetailsModles extends Model{
     
    protected $table= 'kycdetails';
    protected $allowedFields = ['dob','residentarea','aadhaarname','aadhaaraddress','aadhaarfront','aadhaarback','bankaccounttype','accountnum','ifsccode','iskyc'];


    public function savekycdetails($address,$occupation,$dinnum,$aadhaaraddress,$nominee,$kycbod,$panphoto,$residentarea,$aadhaarname,$aadharfrontside,$aadharbackside,$userid,$bankaccounttype,$accountnum,$ifsccode) {
        date_default_timezone_set('Asia/Kolkata');
		$date=date("Y-m-d h:i:sa");
        $iskyc=1;
        $this->db->query("insert into kycdetails(user_id,dob,residentarea,aadhaarname,aadhaaraddress,aadhaarfront,aadhaarback,bankaccounttype,accountnum,ifsccode,iskyc,created_at,updated_at) values ('$userid', '$kycbod','$residentarea','$aadhaarname','$aadhaaraddress','$aadharfrontside','$aadharbackside','$bankaccounttype','$accountnum','$ifsccode','$iskyc','$date','$date')");

    }

    
}
?>