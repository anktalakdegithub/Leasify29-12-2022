<?php namespace App\Models;
use CodeIgniter\Model;
class WalletPaymentRFQModels extends Model{
     
    protected $table= 'user_wallet';
    protected $allowedFields = ['user_id','Amount','payment_method','paymnet_status','is_money','reason','pay_date'];


    // savemoney($nbfc_id,$money,$paymentmethod,$paymentstatus)
    
    public function updateuser($avamoney, $user_id){
        
        // print_r($avamoney);die();
        $demo=$this->db->query("update users set wallet_amount='".$avamoney."' where user_id='".$user_id."'");
        
        
      
    }
    public function update_money($paid,$uwallet){
        // print_r($paid);die();
      
        $demo=$this->db->query("update user_wallet set is_money='".$paid."' where uwallet_id='".$uwallet."'");
        
        
      
    }
}
?>