<?php

namespace App\Controllers;
class Welcome extends BaseController
{
    public function index()
    {
        return view('index');
    }
    public function lease()
    {
        return view('lease');
    }
    public function about()
    {
        return view('about');
    }
    public function thankyou()
    {
        return view('thankyou');
    }
  
    public function contact()
    {
        return view('contact');
    }
  
    public function login()
    {
        return view('login');
    }
    public function signup()
    {
        return view('signup');
    }
    public function notfound()
    {
        // echo 'k';
        return view('notfound');
    }
    public function policy()
    {
        return view('policy');
    }
    public function terms()
    {
        return view('term');
    }
    public function savecondata(){
        $name=$this->request->getPost('name');
        $email=$this->request->getPost('email');
        $selectoption=$this->request->getPost('selectoption');
        $phone=$this->request->getPost('phone');
        $message=$this->request->getPost('message');
//   print_r( $name);die();
        $to='testmailcomp0@gmail.com';
        $subject="Leasify Contact Details";
        $message="Name :".$name."<br/>Email ID: ".$email."<br/> Option ".$selectoption."Contact Number: <br/>".$phone."<br/>Message". $message;
        $email = \Config\Services::email();  
        $email->setTo($to);
        $email->setFrom('testmailcomp0@gmail.com','test');
        $email->setSubject($subject);
        $email->setMessage($message);
        if($email->send()){
          
          return view('contact',$data);
        }
         else{
          $data =$email->printDebugger(['headers']);
          print_r($data);
      }

    }
    public function loginfront()
    {   

        $btninvest=$this->request->getPost('btninvest');
        $btncorporate=$this->request->getPost('btncorporate');
        $btnnbfc=$this->request->getPost('btnnbfc');
        // print_r($btninvest);die();
        $data['btninvest']="Investor";
        $data['btncorporate']="Corporate";
        $data['btnnbfc']="NBFC";
        echo json_encode($data);
       
    }


}    