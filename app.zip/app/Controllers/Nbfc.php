<?php

namespace App\Controllers;
use App\Models\NBFCLoginModles;
use App\Models\LoginModles;
use App\Models\NbfcCreateProposalModels;
use App\Models\InvestorCreateProposalModels;
use App\Models\WalletPaymentRFQModels;
use App\Models\PaymentRFQModels;
use App\Models\ProposalDetailsModels;
use App\Models\NbfcBidModels;
use App\Models\Customer_model;
use CodeIgniter\Database\Query;


class Nbfc extends BaseController
{
    public function index()
    { 
        $session = session();
        if($session->get('isnbfclogin')){
        return view('nbfc/index');
        }
        else{
            return view('nbfc/login');
            // return redirect()->to('login');
        }
    }
    public function edit_rfq()
    {
        return view('nbfc/edit_rfq');
    }
    public function investor()
    {
        return view('nbfc/investor');
    }
    public function login()
    {
        return view('nbfc/login');
    }
    public function money()
    {   
        $session = session();
        if($session->get('isnbfclogin')){
        return view('nbfc/money');
        }
        else{
            return view('nbfc/login');
            // return redirect()->to('login');
        }
    }
    public function my_vault()
    {
        $session = session();
        if($session->get('isnbfclogin')){
            $rfq= new WalletPaymentRFQModels();
            $nbfc_id=$session->get('user_id');
            // print_r($nbfc_id);die();
            // $data['walletdetails']=$rfq->where('user_id',$nbfc_id)->findAll();
            $data['walletdetails']=$rfq->where('user_id',$nbfc_id)->paginate(5);

            $data['walletdetails']=$rfq->where('user_id',$nbfc_id)->paginate(5);
            $result = $rfq->where('user_id',$nbfc_id)->select('sum(Amount) as sumamt')->first();
		    $data['sumdemo'] = $result['sumamt'];

        $rfq->updateuser($data['sumdemo'],$nbfc_id);
            $data['pager']=$rfq->pager;
           
        return view('nbfc/my_vault',$data);
            }
            else{
                return view('nbfc/login');
                // return redirect()->to('login');
            }
    }
    public function new_rfq()
    {
        return view('nbfc/new_rfq');
    }
    public function thanks()
    {
        return view('nbfc/thanks');
    }
    public function newproposallist()
    {
        return view('nbfc/newproposallist');
    }
    public function newproposalsingle()
    {
        return view('nbfc/newproposalsingle');
    }
 
    public function newrfq2()
    {  
        $session = session();
        if($session->get('isnbfclogin')){
        return view('nbfc/newrfq2');
            }
            else{
                return view('nbfc/login');
                // return redirect()->to('login');
            }
    }
    public function order()
    { 
        $session = session();
        if($session->get('isnbfclogin')){
            $nbfc=new NbfcCreateProposalModels();
            $bid=new NbfcBidModels();
            $nbfc_id=$session->get('user_id');
            $user_role=$session->get('$user_role');
            if($user_role=='nbfc'){
          
            $is_nbfc=1;
            // $is_proposal=1;
            $wheres = "is_poroposal=0 OR is_poroposal=1";
            $demo= $nbfc->join('proposal_bid', 'proposal_bid.proposal_id = indicative_proposals.proposal_id')->where('NBFC_publish', $is_nbfc)->where('investor_id', $nbfc_id)->where($wheres)->paginate(5);
            }
            else{
                $is_investor=1;
                $is_proposal=1;
                $wheres = "is_poroposal=0 OR is_poroposal=1";
                $demo= $nbfc->join('proposal_bid', 'proposal_bid.proposal_id = indicative_proposals.proposal_id')->where('investor_publish', $is_investor)->where('investor_id', $nbfc_id)->where($wheres)->paginate(5);
            }

            // print_r("<pre>");      
            // print_r($demo);die();
            $data['pager']=$nbfc->pager;
            $data['all_nbfc_active']= $demo;

        return view('nbfc/order',$data);
        }
        else{
            return view('nbfc/login');
            // return redirect()->to('login');
        }
    }
    // public function payment()
    // {  
    //     $session = session();
    //     if($session->get('isadminlogin')){
    //         $user_id=$session->get('user_id');
    //     $payment= new PaymentRFQModels();
    //     $data['paymentlist']=$payment->findAll();

    //     if($session->get('isnbfclogin')){
    //     return view('nbfc/payment',$data);
    // }
    // else{
    //     return view('nbfc/login');
    // }
    // }
    public function payment()
    {
        $session = session();
        if($session->get('isnbfclogin')){
            $user_id=$session->get('user_id');
            $user_role=$session->get('$user_role');
        //    $payment= new PaymentRFQModels();
        //    $data['paymentlist']=$payment->findAll();
        $pay = new Customer_model();
        $data['payment']=$pay->paymentlist();
        //    $data['paymentlist']=$pay->paginate(5);
           $data['pager']=$pay->pager;
            return view('nbfc/payment',$data);
        }
        else{
            return view('nbfc/login');
            // return redirect()->to('login');
        }
    }
    // public function rfq_details($id)
    // {
    //     $session = session();
    //     if($session->get('isnbfclogin')){
    //         $nbfc= new NbfcCreateProposalModels();
    //     $data['proposaldetails']= $nbfc->find($id);
    //     return view('nbfc/rfq_details',$data);
    // }
    // else{
    //     return view('nbfc/login');
    //     // return redirect()->to('login');
    // }

    // }
    // public function nbfcproposaldetails($id)
    public function nbfcproposaldetails($id)
    {  
        // echo "lkbuj".$id;
        $session = session();
        if($session->get('isnbfclogin')){
            $nbfc= new NbfcCreateProposalModels();
            $proposal= new ProposalDetailsModels();
            // $createproposal= new CreatedProposalDetailsModels();
            // print_r($nbfc);die();
        // $data['proposaldetails']= $nbfc->find($id);
        $data['proposaldetails']= $nbfc->where('proposal_id',$id)->find();
        //  print_r($data['proposaldetails']);die();
        $data['proposalsingledetails']= $proposal->where('proposal_id',$id)->find();
        //  print_r($data['proposalsingledetails']);die();
        // $data['proposalcreatedetails']= $createproposal->where('proposal_id',$id)->find();
        return view('nbfc/nbfcproposaldetails',$data);
    }
    else{
        return view('nbfc/login');
        // return redirect()->to('login');
    }

    }
    public function rfqlist()
    {
        $session = session();
        if($session->get('isnbfclogin')){
            $rfq=new NbfcCreateProposalModels();
            $nbfc_id=$session->get('user_id');
            $user_role=$session->get('$user_role');
           if($user_role=='nbfc'){
            $nbfc=1;
            $data['rfqlists']=$rfq->where('rfq_id',$nbfc_id)->where('NBFC_publish',$nbfc)->findAll();
           }
           else{
            $investor=1;
            $data['rfqlists']=$rfq->where('rfq_id',$nbfc_id)->where('investor_publish',$investor)->findAll();
           }
        //    print_r("<pre>");
        //      print_r($data['rfqlists']);die();
        return view('nbfc/rfqlist',$data);
    }
    else{
        return view('nbfc/login');
        // return redirect()->to('login');
    }

    }
    public function rfqs()
    {   
        $session = session();
        if($session->get('isnbfclogin')){

            $nbfc=new NbfcCreateProposalModels();
            $bid=new NbfcBidModels();
            $nbfc_id=$session->get('user_id');
            $user_role=$session->get('user_role');
            // print_r($user_role);die();   
           
        //    $demo= $nbfc->join('proposal_bid', 'proposal_bid.proposal_id = indicative_proposals.proposal_id')->findAll();
        if($user_role=='investor'){
            $investor=1;
            $wheres = "is_poroposal=3 OR is_poroposal=2";
           $demo= $nbfc->join('proposal_bid', 'proposal_bid.proposal_id = indicative_proposals.proposal_id')->where('indicative_proposals.investor_publish',$investor)->where($wheres)->paginate(5);
        }
        else{
            $nbfcs=1;
            $wheres = "is_poroposal=3 OR is_poroposal=2";
           $demo= $nbfc->join('proposal_bid', 'proposal_bid.proposal_id = indicative_proposals.proposal_id')->where('indicative_proposals.NBFC_publish',$nbfcs)->where($wheres)->paginate(5);
        }
        //             print_r("<pre>");
        //    print_r($demo);die();
        $data['pager']=$nbfc->pager;
            $data['all_nbfc']= $demo;
       
        return view('nbfc/rfqs',$data);
    }
    else{
        return view('nbfc/login');
        // return redirect()->to('login');
    }

    }
    public function deleteproposal(){


        // $nbfc=new NbfcCreateProposalModels();
        // $proposal_bid=$this->request->getPost('proposal_bid');
        // if($proposal_bid!=''){
        //     $proposal_data=$nbfc->deleteproposaldetails($proposal_bid);
        //     print_r($proposal_data);die();
        //     }
        // $nbfcdetails=$nbfc->where('proposal_bid', $proposal_bid)->first();
        //  $data = array('code' => 200, 'data'=> $nbfcdetails, 'msg'=>"NBFC Proposal Data deleted Successfully.");
        // // print_r($data);
        //   echo json_encode($data);



          $nbfc= new NbfcCreateProposalModels();
          $bid=new NbfcBidModels();
          $proposalbid_id=$this->request->getPost('proposalbid_id');
        //   print_r($proposalbid_id);die();   
          if($proposalbid_id!=''){
              $nbfc_data=$nbfc->deleteproposaldetails($proposalbid_id);
            //   print_r($nbfc_data);die();
          }
          $nbfcdetails=$bid->where('proposalbid_id', $proposalbid_id)->first();
           $data = array('code' => 200, 'data'=> $nbfcdetails, 'msg'=>"NBFC Proposal Data deleted Successfully.");
          // print_r($data);
            echo json_encode($data);
       
    }
    
    public function nbfc_login(){
        
         $login=new LoginModles();
        $username=$this->request->getPost('username');
   
         $password=$this->request->getPost('password');
        //  $user_role='nbfc';
        //  $user_role='investor';
    //   $result= $login->where('firstname', $username)->where('user_role', $user_role)->first();
      $result= $login->where('emailid', $username)->first();
    //   print_r($result);die();
      $data=array();
         if(count($result)>0){
             if($password==$result['password']){
                 $login_id =$result['user_id'];
                 $user_role =$result['user_role'];
                 $firstname =$result['firstname'];
                 $session = session();
                 $session_data = array(  
                     'emailid' => $username,
                     'password' => $password
                );  
                
                $session->set('isnbfclogin', true);
                $session->set('nbfcdata', $session_data);
                $session->set('user_id',$login_id);
                $session->set('user_role',$user_role);
                $session->set('firstname',$firstname);
               

       $data = array('code' => 200, 'data'=> array('firstname' => $result['emailid'], 'password' => $result['password'], 'user_role' => $result['user_role']), 'msg'=>"Login Successfully.");
    
    }
     else{
         $data = array('code' => 404, 'data'=> array('firstname' => $result['emailid'], 'password' => $result['password'], 'user_role' => $result['user_role']), 'msg'=>"Please enter correct Details");
     }
 }
 else{
     $this->session->set_flashdata('error', 'Invalid Username and Password');  
     $data = array('code' => 404, 'data'=> array(), 'msg'=>"Invalid Username and Password.");
 }
 echo json_encode($data);
  
 
     }

     public function addmoney(){
        $wallet=new WalletPaymentRFQModels;
        $session = session();
        $user_id=$session->get('user_id');
        $avamoney=$this->request->getPost('avamoney');
        // $wallet->updateuser($avamoney,$user_id);
        // $money=$this->request->getPost('money');
        //  print_r($avamoney);die();
      $paymentmethod="Gpay";
      date_default_timezone_set('Asia/Kolkata');
		$date=date("Y-m-d h:i:sa");
      $pay_date=$date;
      $paymentstatus="Success";
      $ismoney=1;
    //   print_r($ismoney);die();
        // $wallet->savemoney($user_id,$money,$paymentmethod,$paymentstatus);
        //   die($demo);
        $amount=$this->request->getPost('money');
        if(empty($amount)){
                  
            $data=['code'=>'404','msg'=>'Please Enter Money'];
       }
      else{
        $data=[
            'Amount' =>$amount,
            'payment_method' =>$paymentmethod,
            'pay_date' =>$pay_date,
                'paymnet_status' =>$paymentstatus,
                'is_money' => $ismoney,
                'user_id' => $user_id   
            ];
           
// print_r($data);die();
          
             $wallet->save($data);
             
          $data = ['code'=>'200','msg'=>'Money Added Successfully'];
            }
          return $this->response->setJSON($data);

     }
     public function withdrawmoney(){
        $wallet=new WalletPaymentRFQModels;
        $session = session();
        $user_id=$session->get('user_id');
        $avamoney=$this->request->getPost('avamoney');
      $paymentmethod="Gpay";
      date_default_timezone_set('Asia/Kolkata');
		$date=date("Y-m-d h:i:sa");
      $pay_date=$date;
      $paymentstatus="Success";
      $ismoney=0;
      $reason="Withdraw";
    //    print_r($user_id);die();
        // $wallet->savemoney($user_id,$money,$paymentmethod,$paymentstatus);
        //   die($demo);
        $widreamamt=$this->request->getPost('withdrawmoney');
        if(empty($widreamamt)){
                  
            $data=['code'=>'404','msg'=>'Please Enter Money'];
       }
      else{
        $data=[
            'Amount' =>-($widreamamt),
            'payment_method' =>$paymentmethod,
            'pay_date' =>$pay_date,
                'paymnet_status' =>$paymentstatus,
                'reason' =>$reason,
                'user_id' => $user_id,
                'is_money' => $ismoney
            ];
            // print_r("<pre>");
            // print_r($data);
            // die();
            // if($avamoney>=10000){
         

             $wallet->save($data);
            $wallet->updateuser($avamoney,$user_id);
       
          
           
        
          $data = ['code'=>'200','msg'=>'Withdraw Money Successfully'];
            }
          return $this->response->setJSON($data);

     }
     public function addbid(){
        $nbfc=new NbfcBidModels;
        $session = session();
        $nbfc_id=$session->get('user_id');
        $user_role=$session->get('user_role');
            
        $file = $this->request->getFile('nbfcfile');
      
        $imgName='';
        if(!empty($file)){
           if ($file->isValid() && ! $file->hasMoved()) {
            $imgName = $file->getRandomName();
            $file->move('./public/nbfc/', $imgName);
           }
        }

           $nbfcbid=$this->request->getPost('nbfcbid');
           $customer_id=$this->request->getPost('customer_id');
            //    print_r($nbfcbid);
            $nbfcfile='/public/nbfc/'.$imgName;
            $propid=$this->request->getPost('propid');
            if(empty($nbfcbid)){
                  
                 $data=['code'=>'404','msg'=>'Please Enter BID'];
            }else if(empty($file)){
                  
                 $data=['code'=>'404','msg'=>'Please Upload File'];
            }else{
                
           $nbfcc= $nbfc->savebis($nbfc_id,$nbfcbid,$nbfcfile,$propid,$customer_id);
        //    $demoo=$nbfc->updatebid($nbfc_id,$nbfcbid,$propid);
          
            $data=['code'=>'200','msg'=>'BID Added Successfully'];
           
            // $data = ['code'=>'200','msg'=>'BID Added Successfully'];
            // return $this->response->setJSON($data);
            }
            return $this->response->setJSON($data);

     }
    //  public function addbid(){
    //     $nbfc=new NbfcBidModels;
    //     $session = session();
    //     $nbfc_id=$session->get('nbfc_id');
    //     $file = $this->request->getFile('nbfcfile');
      
    //        $imgName='';
    //        if(!empty($file)){
    //           if ($file->isValid() && ! $file->hasMoved()) {
    //            $imgName = $file->getRandomName();
    //            $ext = $file->getClientExtension();
    //             $file->move(WRITEPATH . 'nbfc');
           
    //           }
    //        }
    //        $nbfcbid=$this->request->getPost('nbfcbid');
    //         $nbfcfile=$imgName;
    //         $propid=$this->request->getPost('propid');
    //         $nbfcc=$nbfc->savebis($nbfc_id,$nbfcbid,$nbfcfile,$propid);
    //       $data = ['status'=>'NBFC Bid added Successfully','msg'=>'NBFC Bid added Successfully'];
    //           return $this->response->setJSON($data);
    //         $data = ['status'=>'BID Added Successfully','msg'=>'BID Added Successfully'];
    //       return $this->response->setJSON($data);

    //  }
     public function logout(){
        $session = session();
        $session->destroy();
        return view('nbfc/login');
       }

       public function fetch_category()
{
    $session = session();
	$output = '';
    $start=$this->request->getPost('start');
    $limit=$this->request->getPost('limit');
  $page=$this->request->getPost('page');
    $skip = $limit*$page;

 $rfq=new NbfcCreateProposalModels();

 $nbfc_id=$session->get('user_id');
// print_r($nbfc_id);die();
//  $datas=$rfq->where('rfq_id',$nbfc_id);
$dataall=array();
if($session->get('user_role')=="investor"){

    $dataall=$rfq->where('investor_publish', '1')->findAll($limit,$start);
}
else if($session->get('user_role')=="nbfc"){

    $dataall=$rfq->where('NBFC_publish', '1')->findAll($limit,$start);
}
 
//   if($data->countAll() > 0)
//   {
  //  print_r($data->findAll());
 //   die();
 
   foreach($dataall as $row)
   {
   
        $output .= '<div class="col-md-4 my-2">
        <a href="'.base_url().'/nbfc/nbfcproposaldetails/'.$row['proposal_id'].'">
            
            <div class="card h-100">
                <div class="card-body text-dark">
                    <div class="row mb-4">
                        <div class="col-3">
                            <img src="'.base_url().''.$row['proposal_logo'].'" height="65px"
                                width="75px" class="shadow-lg me-3 imgborder" alt="">
                        </div>
                        <div class="col-9">
                            <h5 class="card-title proptitle">'.$row['proposal_title'].'</h5>
                            <!-- <p class="card-text"></p> -->
                            <p><?php echo date("d-m-Y", strtotime('.$row['proposal_date'].'));?></p>
</div>
</div>

<p>'.$row['proposal_details'].'</p>
<div class="row">
    <div class="col-4 py-2 bordercolrs sideborder">
        <small>Pre-Tax IRR</small>
        <h5 class="mt-4">'.$row['pre_tax'].'</h5>
    </div>
    <div class="col-4 py-2 bordercolrs">
        <small>Tenure</small>
        <h5 class="mt-4">'.$row['tenure'].'M</h5>
    </div>
    <div class="col-4 py-2 bordercolrs sideborder">
        <small>Minimum Investment</small>
        <h5 class="">'.$row['min_investment'].'</h5>
    </div>
</div>



<p class="my-2"><b>Amount Raised: </b><i class="bx bx-rupee"></i>'.$row['min_investment'].'</p>

</div>
</div>
</a>
</div>';




}

// }
echo $output;
}


}