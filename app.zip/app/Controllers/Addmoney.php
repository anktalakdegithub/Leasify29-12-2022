<?php
namespace App\Controllers;
use App\Models\Deal_model;
// defined('BASEPATH') OR exit('No direct script access allowed');
//require 'vendor/autoload.php';
require_once(APPPATH."libraries/config_paytm.php");
require_once(APPPATH."libraries/encdec_paytm.php");


class Addmoney extends BaseController {
  public function __construct()
	{
	// parent::__construct();
	  $db = db_connect();
    $this->session = \Config\Services::session();
		$this->Deal_model = new Deal_model($db);


  }
	public function index()
	{
    // $this->load->library('session'); 
    // $userdata = $this->session->get('userdata');
  //  print_r($userdata['contact']);
  // echo 'hello';
  // die;
  

      $paramList["MID"] = PAYTM_MERCHANT_MID;
      // $paramList["ORDER_ID"] = $userdata['user_id'].uniqid();     
      // $paramList["CUST_ID"] = $userdata['user_id'];   /// according to your logic
      $paramList["ORDER_ID"] = "1";     
      $paramList["CUST_ID"] = "1";   /// according to your logic
      $paramList["INDUSTRY_TYPE_ID"] = 'Retail';
      $paramList["CHANNEL_ID"] = 'WEB';
      $paramList["TXN_AMOUNT"] = "1";
      $paramList["WEBSITE"] = PAYTM_MERCHANT_WEBSITE;

      $paramList["CALLBACK_URL"] = base_url().'/Addmoney/payment_response?student_id=1';
      $paramList["MSISDN"] ="7588659834"; //Mobile number of customer
      $paramList["EMAIL"] ="ankitalakde06@gmail.com";
      $paramList["VERIFIED_BY"] = "EMAIL"; //
      $paramList["IS_USER_VERIFIED"] = "YES"; //
      //  print_r($paramList);
        $checkSum = getChecksumFromArray($paramList,PAYTM_MERCHANT_KEY);

         $output='<form id="myForm" action="'.PAYTM_TXN_URL.'" method="post">';
         
         foreach ($paramList as $a => $b) {
        $output.='<input type="hidden" name="'.htmlentities($a).'" value="'.htmlentities($b).'">';
       }
       
            $output.='<input type="hidden" name="CHECKSUMHASH" value="'.$checkSum.'">
        </form>
        <script type="text/javascript">
            document.getElementById("myForm").submit();
         </script>';
       echo $output;
	}

	public function payment_response(){
		$student_id=$this->request->getGet('student_id');
		$user=$this->Deal_model->get_user_data($student_id);
    $userdata = $this->session->get('userdata');

		$paytmChecksum = "";
        $paramList = array();
        $isValidChecksum = "FALSE";
        $paramList = $_POST;

        print_r($paramList);
        // if($paramList['STATUS']=="TXN_SUCCESS"){
        // 	$user_id=$userdata['user_id'];
        //   $deal_data = [
        //     'payment_status'		=> 'paid',
        //   ];
        // 	// $course_id=1;
        // 	$this->User_Model->update_payment($user_id,$deal_data);
        // 	redirect('thankyou');
        // }
        // else{
        // 	//redirect('checkout');
        // 	redirect('students');
        // }
	}
	public function scholarship()
	{
		$scholarship_id=$this->session->userdata('scholarship_id');
		//echo $scholarship_id;
		$paramList["MID"] = PAYTM_MERCHANT_MID;
        $paramList["ORDER_ID"] = $scholarship_id.rand();     
        $paramList["CUST_ID"] = $scholarship_id;   /// according to your logic
        $paramList["INDUSTRY_TYPE_ID"] = 'Retail';
        $paramList["CHANNEL_ID"] = 'WEB';
        $paramList["TXN_AMOUNT"] = 1000;
        $paramList["WEBSITE"] = PAYTM_MERCHANT_WEBSITE;
   
        $paramList["CALLBACK_URL"] = base_url().'checkout/scholarship_response?scholarship_id='.$scholarship_id;
        $paramList["MSISDN"] = ""; //Mobile number of customer
        $paramList["EMAIL"] ='';
        $paramList["VERIFIED_BY"] = "EMAIL"; //
        $paramList["IS_USER_VERIFIED"] = "YES"; //
      //  print_r($paramList);
        $checkSum = getChecksumFromArray($paramList,PAYTM_MERCHANT_KEY);

        ?>

        <!--submit form to payment gateway OR in api environment you can pass this form data-->
   
        <form id="scholarship_form" action="<?php echo PAYTM_TXN_URL ?>" method="post">
        <?php
         foreach ($paramList as $a => $b) {
        	echo '<input type="hidden" name="'.htmlentities($a).'" value="'.htmlentities($b).'">';
       	}
       ?>
            <input type="hidden" name="CHECKSUMHASH" value="<?php echo $checkSum ?>">
	        </form>
	        <script type="text/javascript">
	          document.getElementById('scholarship_form').submit();
	         </script>
	 
		<?php
	}
	public function scholarship_response(){
		$scholarship_id=$this->input->get('scholarship_id');
		$paytmChecksum = "";
        $paramList = array();
        $isValidChecksum = "FALSE";
        $paramList = $_POST;
        if($paramList['STATUS']=="TXN_SUCCESS"){
        	$course_id=1;
        	$this->User_Model->update_scholarship_status($scholarship_id);
        	redirect('thankyou');
        }
        else{
        	$student_id=$this->session->userdata('user_id');
        	redirect('checkout/scholarship');
        }
	}
	
}
