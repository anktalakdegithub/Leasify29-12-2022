<?php

namespace App\Controllers;
use App\Models\LoginModles;
class Login extends BaseController
{
    public function registeration(){
      
        $login=new LoginModles();
        $fname=$this->request->getPost('fname');
        $lname=$this->request->getPost('lname'); 
      
        $mobilenum=$this->request->getPost('mobilenum');  
        $email=$this->request->getPost('email'); 
    
        $user_role="customer";
        $login->savereg($fname,$lname,$mobilenum,$email,$user_role);    
      $data = ['status'=>'Registration Done Successfully','msg'=>'Registration Done Successfully'];
      
      return $this->response->setJSON($data);

      
    }


    public function process_otp(){
      $login=new LoginModles();
      $otpv=$this->request->getPost('otpv');
     $session = session();
     $session_otp=$session->get('otp');
      $data=array();
   
      if($otpv==$session_otp){
        $data = array('code' => 200, 'data'=> array(), 'msg'=>"Otp Added Successfully.");
      }
      else{

          $data = array('code' => 404, 'data'=> array(), 'msg'=>"Please enter correct OTP.");
      }
      echo json_encode($data);
  
     
    }
    public function process_login(){
       
         $login=new LoginModles();
        $phone=$this->request->getPost('phone');

     $result= $login->where('emailid', $phone)->first();

          $data=array();
         if($result!=''){

         if($phone==$result['emailid']){
                // print_r('jkbhj');
                 $user_id =$result['user_id'];
                 $firstname =$result['firstname'];
                 $emailid =$result['emailid'];
                 $otp=mt_rand(2000,9000);

               $session = session();
                 $session_data = array(  
                     'emailid'=> $phone,
                );  

                $session->set('isadminlogin', true);
                $session->set('admindata', $session_data);
                $session->set('user_id',$user_id);
                $session->set('otp',$otp);
                $session->set('emailid',$emailid);
                $session->set('firstname',$firstname);
                
                    $data = array('code' => 200, 'data'=> array('emailid'=> $result['emailid']), 'msg'=>"Login Successfully.");
                    }
                    else{

                        $data = array('code' => 404, 'data'=> array(), 'msg'=>"Please enter correct Details");
                    }
                }
                else{
//die();
                    //$this->session->set_flashdata('error', 'Invalid Mobile Number');  
  
                  $data = array('code' => 404, 'data'=> array(), 'msg'=>"Invalid Email Id.");
                }
                echo json_encode($data);

 
     }

     public function logout(){
        $session = session();
        $session->destroy();
        return view('home/login');
       }

       public function process_signup(){
        $fname=$this->request->getPost('fname');
        $lname=$this->request->getPost('lname');
        $email=$this->request->getPost('email');
        $phone=$this->request->getPost('phone');
        $user_type=$this->request->getPost('user_type');
        $password=$this->request->getPost('password');
        $proposal= new LoginModles();
   
        // print_r($user_type);die();
      
        if(empty($fname)){
          $data=['code'=>'404','msg'=>'Please Enter Name'];
        }else if(empty($email)){
           
          $data=['code'=>'404','msg'=>'Please Enter email'];
      }else if(empty($phone)){
           
        $data=['code'=>'404','msg'=>'Please Enter Contact Number'];
    }else if(empty($user_type)){
                  
          $data=['code'=>'404','msg'=>'Please Select User Type'];
     }else{
       $login=$proposal->savesignup($fname,$lname,$email,$phone,$user_type,$password);
      //  print_r($login);die();
       $data=['code'=>'200','msg'=>'BID Added Successfully'];
      }
      return $this->response->setJSON($data);
        
      }
   
}